//
//  ThirdViewController.h
//  NavigationTest2
//
//  Created by Jonnyqian on 2016/12/14.
//  Copyright © 2016年 Jonnyqian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController
@property(strong,nonatomic)NSValue *number;//接收来自A  controller传来的值
@end
